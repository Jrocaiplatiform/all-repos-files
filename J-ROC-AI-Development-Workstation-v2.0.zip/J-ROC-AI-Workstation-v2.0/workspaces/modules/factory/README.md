# J-ROC AI Factory & Application Factory Workspace
App, website, database, API & agent builders with local-first packaging.
