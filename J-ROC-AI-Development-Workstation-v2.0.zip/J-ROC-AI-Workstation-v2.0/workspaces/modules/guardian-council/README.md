# J-ROC AI Guardian Council Workspace
AI safety governance, policy enforcement & human approval gates.
