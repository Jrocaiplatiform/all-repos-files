# J-Bot & AI Brain Workspace
Local LLM routing, voice assistant, memory & human-approved task agents.
