# Kali Linux Security Lab Workspace
Isolated authorized penetration testing, vulnerability assessment & digital forensics environment.
