# Android (AOSP) Platform Workspace
Android Open Source Project foundation & Jrocai1/J-ROC-AI-Phone-OS integration point.
