# Automotive & Connected Devices Workspace
Android Automotive integration, EV diagnostics, kiosks & smart home IoT.
