# Smart TV Workspace
J-ROC AI Connected Device OS 10-foot media & smart-home interface.
