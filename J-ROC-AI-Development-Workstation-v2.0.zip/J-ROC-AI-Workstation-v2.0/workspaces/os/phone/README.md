# Phone OS Workspace
Smartphones, telephony, SMS/RCS, mobile security & AOSP integration.
