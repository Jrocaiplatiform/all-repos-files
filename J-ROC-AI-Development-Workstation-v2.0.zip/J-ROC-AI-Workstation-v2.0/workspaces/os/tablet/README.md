# Tablet OS Workspace
Tablet form-factor UI, stylus support & cross-device handoff.
