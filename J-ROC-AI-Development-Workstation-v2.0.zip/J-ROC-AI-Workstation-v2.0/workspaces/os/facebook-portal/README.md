# Facebook Portal Workspace
Supported smart display application & video communications integration.
