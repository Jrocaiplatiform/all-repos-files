@echo off
setlocal
title J-ROC AI Development Workstation v2.0 - Installer

set "INSTALL_DIR=%USERPROFILE%\J-ROC-AI-Workstation"
set "SOURCE_DIR=%~dp0"

echo ====================================================================
echo   J-ROC AI Development Workstation v2.0 - Full Ecosystem Edition
echo   Windows 10 / Windows 11 · Local-First · $0 Budget Gate
echo ====================================================================
echo.
echo [1/4] Installing upgraded workstation files to:
echo       %INSTALL_DIR%
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
xcopy "%SOURCE_DIR%*" "%INSTALL_DIR%\" /E /I /H /Y >nul

echo [2/4] Updating Desktop installation shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $sc = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\J-ROC AI Workstation.lnk'); ^
   $sc.TargetPath = '%INSTALL_DIR%\Launch-Workstation.bat'; ^
   $sc.WorkingDirectory = '%INSTALL_DIR%'; ^
   $sc.Description = 'J-ROC AI Development Workstation v2.0'; ^
   $sc.IconLocation = 'shell32.dll,21'; ^
   $sc.Save()"

echo [3/4] Configuring automatic workstation startup...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $startup = [Environment]::GetFolderPath('Startup') + '\J-ROC AI Workstation.lnk'; ^
   $sc = $ws.CreateShortcut($startup); ^
   $sc.TargetPath = '%INSTALL_DIR%\Launch-Workstation.bat'; ^
   $sc.WorkingDirectory = '%INSTALL_DIR%'; ^
   $sc.Description = 'Auto-start J-ROC AI Development Workstation v2.0'; ^
   $sc.IconLocation = 'shell32.dll,21'; ^
   $sc.Save()"

echo [4/4] Launching J-ROC AI Workstation v2.0 Dashboard...
start "" "%INSTALL_DIR%\dashboard\index.html"

echo.
echo Upgrade & installation complete!
pause
