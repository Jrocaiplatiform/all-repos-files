@echo off
title J-ROC AI Development Workstation v2.0
set "ROOT_DIR=%~dp0"
start "" "%ROOT_DIR%dashboard\index.html"
