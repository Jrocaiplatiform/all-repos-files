# J-ROC AI Mobile OS

- **Foundation:** Android Open Source Project (AOSP)
- **Target Devices:** Smartphones, Tablets
- **Core Scope:** Calls, SMS/RCS, mobile apps, device repair, mobile security, connectivity
