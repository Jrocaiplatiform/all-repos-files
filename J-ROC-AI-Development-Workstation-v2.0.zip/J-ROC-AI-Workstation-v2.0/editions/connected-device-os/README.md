# J-ROC AI Connected Device OS

- **Foundation:** Linux Embedded + Supported App Integration
- **Target Devices:** Tablets, Smart TVs, Facebook Portal, Smart Displays, Kiosks, Automotive & IoT
- **Core Scope:** Dedicated interfaces, kiosks, smart displays, connected equipment
