# J-ROC AI Desktop OS

- **Foundation:** Linux + Windows Native/Compatibility Layer
- **Target Devices:** Laptops, Desktop Computers, Workstations
- **Core Scope:** Desktop apps, multitasking, local AI, software development
