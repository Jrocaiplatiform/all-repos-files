# J-ROC AI Enterprise OS

- **Foundation:** Linux Server Foundation
- **Target Devices:** Servers, Enterprise Infrastructure
- **Core Scope:** Centralized admin, IAM, security operations, fleet management
