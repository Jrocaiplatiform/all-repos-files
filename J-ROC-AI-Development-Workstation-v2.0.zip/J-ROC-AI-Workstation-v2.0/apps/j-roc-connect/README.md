# J-ROC Connect

- **System Role:** Unified communications, messaging bridges and networking
- **Architecture Layer:** J-ROC AI First-Party System Application
