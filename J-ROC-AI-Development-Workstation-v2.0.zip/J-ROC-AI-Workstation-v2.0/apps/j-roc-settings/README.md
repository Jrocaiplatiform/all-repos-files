# J-ROC Settings

- **System Role:** System configuration, accounts, hardware and synchronization
- **Architecture Layer:** J-ROC AI First-Party System Application
