# J-ROC Assistant

- **System Role:** Voice control, local LLM and autonomous AI workflows
- **Architecture Layer:** J-ROC AI First-Party System Application
