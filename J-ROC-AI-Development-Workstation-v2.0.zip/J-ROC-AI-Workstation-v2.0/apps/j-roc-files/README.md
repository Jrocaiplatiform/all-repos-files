# J-ROC Files

- **System Role:** Files, encrypted vaults, backups and storage
- **Architecture Layer:** J-ROC AI First-Party System Application
