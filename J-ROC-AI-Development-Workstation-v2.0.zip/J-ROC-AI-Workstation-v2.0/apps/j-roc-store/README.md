# J-ROC Store

- **System Role:** Signed applications, compatibility packages and updates
- **Architecture Layer:** J-ROC AI First-Party System Application
