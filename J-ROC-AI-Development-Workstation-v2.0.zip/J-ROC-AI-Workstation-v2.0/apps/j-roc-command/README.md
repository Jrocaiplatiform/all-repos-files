# J-ROC Command

- **System Role:** System administration, terminal, fleet and Guardian Council
- **Architecture Layer:** J-ROC AI First-Party System Application
