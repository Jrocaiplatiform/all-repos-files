# J-ROC Security

- **System Role:** Zero-trust policy, privacy indicators and threat protection
- **Architecture Layer:** J-ROC AI First-Party System Application
