# J-ROC Repair

- **System Role:** Universal Pro Repair, CAM PRO, ODIN Web, J-Bot diagnostics
- **Architecture Layer:** J-ROC AI First-Party System Application
