param(
    [Parameter(Mandatory=$true)]
    [string]$Name,
    [string]$Edition = "desktop-os"
)

$RootDir = Split-Path -Parent $PSScriptRoot
$SafeName = $Name -replace '[^a-zA-Z0-9_-]', '-'
$ProjectPath = Join-Path $RootDir "projects\$SafeName"

if (Test-Path $ProjectPath) {
    Write-Host "[WARN] Project already exists at $ProjectPath" -ForegroundColor Yellow
    exit 1
}

New-Item -ItemType Directory -Path "$ProjectPath\src" -Force | Out-Null
New-Item -ItemType Directory -Path "$ProjectPath\docs" -Force | Out-Null
New-Item -ItemType Directory -Path "$ProjectPath\tests" -Force | Out-Null
New-Item -ItemType Directory -Path "$ProjectPath\scripts" -Force | Out-Null

$Meta = @"
{
  "project": "$SafeName",
  "edition_or_module": "$Edition",
  "workstation_version": "2.0.0",
  "foundation": "Hybrid Linux + Android (AOSP)",
  "budget_gate": "$0",
  "created": "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
  "local_first": true
}
"@
Set-Content -Path "$ProjectPath\project.json" -Value $Meta -Encoding UTF8

$Readme = @"
# $SafeName

- **Target Edition / Module:** $Edition
- **Workstation:** J-ROC AI Development Workstation v2.0
- **Architecture:** Hybrid Linux + AOSP · Local-First · $0 Budget Gate
"@
Set-Content -Path "$ProjectPath\README.md" -Value $Readme -Encoding UTF8

Write-Host "[OK] Scaffolded project folder: $ProjectPath" -ForegroundColor Green
