param(
    [ValidateSet("Enable", "Disable")]
    [string]$Action = "Enable"
)
$StartupPath = Join-Path ([Environment]::GetFolderPath("Startup")) "J-ROC AI Workstation.lnk"
$RootDir = Split-Path -Parent $PSScriptRoot
$Launcher = Join-Path $RootDir "Launch-Workstation.bat"

if ($Action -eq "Enable") {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($StartupPath)
    $sc.TargetPath = $Launcher
    $sc.WorkingDirectory = $RootDir
    $sc.Description = "Auto-start J-ROC AI Development Workstation v2.0"
    $sc.IconLocation = "shell32.dll,21"
    $sc.Save()
    Write-Host "[OK] Automatic workstation startup ENABLED." -ForegroundColor Green
} else {
    if (Test-Path $StartupPath) {
        Remove-Item $StartupPath -Force
        Write-Host "[OK] Automatic workstation startup DISABLED." -ForegroundColor Yellow
    }
}
