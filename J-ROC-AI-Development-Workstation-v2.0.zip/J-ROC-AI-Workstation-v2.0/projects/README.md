# Projects Directory
Local project folders created via `scripts/New-Project.ps1` or the v2.0 dashboard.
