# Tablet OS Workspace
Local workspace for tablet form-factor interfaces and touch-friendly dashboard layouts.
