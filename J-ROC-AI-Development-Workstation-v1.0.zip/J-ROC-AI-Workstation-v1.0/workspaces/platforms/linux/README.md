# Linux Platform Workspace
Local workspace for Linux shell scripts, service configurations, and container definitions.
