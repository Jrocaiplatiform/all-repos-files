# Factory Workspace
Local starter workspace for project scaffolding, build templates, and packaging scripts.
