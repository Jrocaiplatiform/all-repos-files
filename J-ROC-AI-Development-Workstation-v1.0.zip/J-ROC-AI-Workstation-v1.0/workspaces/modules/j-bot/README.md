# J-Bot Workspace
Local starter workspace for J-Bot agent prompts, local task workflows, and automation scripts.
