# Academy Workspace
Local starter workspace for technical study modules, troubleshooting labs, and reference guides.
