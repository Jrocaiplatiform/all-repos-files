@echo off
setlocal
title J-ROC AI Development Workstation v1.0 - Installer

set "INSTALL_DIR=%USERPROFILE%\J-ROC-AI-Workstation"
set "SOURCE_DIR=%~dp0"

echo ============================================================
echo   J-ROC AI Development Workstation - Windows 10 / 11 v1.0
echo ============================================================
echo.
echo [1/4] Installing workstation files to:
echo       %INSTALL_DIR%
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
xcopy "%SOURCE_DIR%*" "%INSTALL_DIR%\" /E /I /H /Y >nul

echo [2/4] Creating Desktop installation shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $sc = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\J-ROC AI Workstation.lnk'); ^
   $sc.TargetPath = '%INSTALL_DIR%\Launch-Workstation.bat'; ^
   $sc.WorkingDirectory = '%INSTALL_DIR%'; ^
   $sc.Description = 'J-ROC AI Development Workstation v1.0'; ^
   $sc.IconLocation = 'shell32.dll,21'; ^
   $sc.Save()"

echo [3/4] Configuring automatic workstation startup (Windows Startup folder)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $startup = [Environment]::GetFolderPath('Startup') + '\J-ROC AI Workstation.lnk'; ^
   $sc = $ws.CreateShortcut($startup); ^
   $sc.TargetPath = '%INSTALL_DIR%\Launch-Workstation.bat'; ^
   $sc.WorkingDirectory = '%INSTALL_DIR%'; ^
   $sc.Description = 'Auto-start J-ROC AI Development Workstation'; ^
   $sc.IconLocation = 'shell32.dll,21'; ^
   $sc.Save()"

echo [4/4] Launching J-ROC AI Development Dashboard...
start "" "%INSTALL_DIR%\dashboard\index.html"

echo.
echo Installation complete!
echo - Desktop shortcut created: J-ROC AI Workstation
echo - Auto-startup enabled in Windows Startup folder
echo - Local-first mode active (no Git or cloud account required)
echo.
pause
