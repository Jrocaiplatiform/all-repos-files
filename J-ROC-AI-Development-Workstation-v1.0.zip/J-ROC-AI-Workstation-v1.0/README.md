# J-ROC AI Development Workstation · Version 1.0

**Target Platform:** Windows 10 / Windows 11  
**Release Type:** Local Workstation Starter (v1.0)

## Scope & Important Distinction
This Version 1.0 release is a **working local workstation starter**, not yet the complete autonomous J-ROC AI operating system. It provides an offline-ready directory structure, Windows installer/startup scripts, a local browser dashboard, and project scaffolding tools without requiring Git or paid cloud services.

## Included Features
- **Desktop Installation Shortcut:** Automatically created via `Install-Workstation.bat`.
- **Local Development Dashboard:** Self-contained HTML/JS control panel (`dashboard/index.html`).
- **Automatic Workstation Startup:** Configured in the Windows Startup folder during installation (can be toggled anytime with `scripts/Toggle-Startup.ps1`).
- **OS Workspaces:** `workspaces/os/` (`phone`, `desktop`, `tablet`, `laptop`).
- **Platform Workspaces:** `workspaces/platforms/` (`linux`, `kali-linux`, `android`, `ios`).
- **Core J-ROC Workspaces:** `workspaces/modules/` (`j-bot`, `factory`, `academy`, `universal-repair`).
- **Project Folder Creation & Management:** Interactive CLI menu (`scripts/Project-Manager.bat`), PowerShell generator (`scripts/New-Project.ps1`), and dashboard project tracker.
- **Local-First Operation:** Zero dependency on Git, external APIs, or paid cloud subscriptions.

## Quick Start (Windows 10 / 11)
1. Extract the ZIP archive to any folder.
2. Double-click **`Install-Workstation.bat`**.
3. The installer copies the workstation to `%USERPROFILE%\J-ROC-AI-Workstation`, creates the **J-ROC AI Workstation** Desktop shortcut, registers automatic startup, and opens the local dashboard.
