# Projects Directory
Store and organize local project folders here using `scripts/Project-Manager.bat` or `scripts/New-Project.ps1`.
