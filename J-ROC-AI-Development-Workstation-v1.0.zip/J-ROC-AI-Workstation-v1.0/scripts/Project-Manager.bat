@echo off
title J-ROC AI Project Folder Manager
setlocal
:MENU
cls
echo ============================================================
echo   J-ROC AI Workstation v1.0 - Project Folder Manager
echo ============================================================
echo   1. Create a new project folder
echo   2. List existing projects
echo   3. Open projects folder in File Explorer
echo   4. Exit
echo.
set /p CHOICE="Select an option (1-4): "

if "%CHOICE%"=="1" goto CREATE
if "%CHOICE%"=="2" goto LIST
if "%CHOICE%"=="3" goto OPEN
if "%CHOICE%"=="4" exit /b
goto MENU

:CREATE
set /p PNAME="Enter project folder name: "
set /p PCAT="Enter workspace category (j-bot/factory/academy/universal-repair/desktop/linux/android/ios): "
if "%PCAT%"=="" set PCAT=factory
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0New-Project.ps1" -Name "%PNAME%" -Category "%PCAT%"
pause
goto MENU

:LIST
echo.
echo Current project folders:
dir /b "%~dp0..\projects"
echo.
pause
goto MENU

:OPEN
start "" "%~dp0..\projects"
goto MENU
