param(
    [Parameter(Mandatory=$true)]
    [string]$Name,
    [ValidateSet("j-bot", "factory", "academy", "universal-repair", "desktop", "laptop", "tablet", "phone", "linux", "kali-linux", "android", "ios")]
    [string]$Category = "factory"
)

$RootDir = Split-Path -Parent $PSScriptRoot
$SafeName = $Name -replace '[^a-zA-Z0-9_-]', '-'
$ProjectPath = Join-Path $RootDir "projects\$SafeName"

if (Test-Path $ProjectPath) {
    Write-Host "[WARN] Project already exists at $ProjectPath" -ForegroundColor Yellow
    exit 1
}

New-Item -ItemType Directory -Path "$ProjectPath\src" -Force | Out-Null
New-Item -ItemType Directory -Path "$ProjectPath\docs" -Force | Out-Null
New-Item -ItemType Directory -Path "$ProjectPath\scripts" -Force | Out-Null

$Meta = @"
{
  "project": "$SafeName",
  "category": "$Category",
  "workstation_version": "1.0.0",
  "created": "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
  "local_first": true
}
"@
Set-Content -Path "$ProjectPath\project.json" -Value $Meta -Encoding UTF8

$Readme = @"
# $SafeName

- **Workspace Category:** $Category
- **Workstation:** J-ROC AI Development Workstation v1.0
- **Mode:** Local-First (No Git or Cloud Required)
"@
Set-Content -Path "$ProjectPath\README.md" -Value $Readme -Encoding UTF8

Write-Host "[OK] Created project folder: $ProjectPath" -ForegroundColor Green
